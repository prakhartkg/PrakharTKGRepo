package com.yash.EmployeeInformation;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World! hello world" );
        System.out.println("prakhar jain");
        System.out.println("nikhilesh sadhav");
        System.out.println("BLAH BLAH -------- NO ONE ON SHASHANK PC --------");
        System.out.println("This is prakhar again");
        System.out.println("Hello Pratik");
        System.out.println("hi pratik sethia");
    }
}
