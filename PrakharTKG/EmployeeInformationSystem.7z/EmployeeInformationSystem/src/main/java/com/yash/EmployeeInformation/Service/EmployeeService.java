package com.yash.EmployeeInformation.Service;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;

/**
 * Session Bean implementation class EmployeeService
 */
@Stateless
@LocalBean
public class EmployeeService implements EmployeeServiceLocal {

    /**
     * Default constructor. 
     */
    public EmployeeService() {
        // TODO Auto-generated constructor stub
    }

}
