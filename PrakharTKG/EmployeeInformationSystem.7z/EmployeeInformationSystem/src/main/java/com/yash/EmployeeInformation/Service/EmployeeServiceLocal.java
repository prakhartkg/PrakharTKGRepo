package com.yash.EmployeeInformation.Service;

import javax.ejb.Local;

@Local
public interface EmployeeServiceLocal {

}
