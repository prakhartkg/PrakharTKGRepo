package com.yash.EmployeeInformation.dao;

public interface EmployeeDao {

}
