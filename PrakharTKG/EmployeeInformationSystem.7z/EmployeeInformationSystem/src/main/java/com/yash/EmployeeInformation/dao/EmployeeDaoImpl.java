package com.yash.EmployeeInformation.dao;


public class EmployeeDaoImpl implements EmployeeDao{

}
