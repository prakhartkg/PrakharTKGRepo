package com.yash.EmployeeInformation.domain;

public class Employee {

}
