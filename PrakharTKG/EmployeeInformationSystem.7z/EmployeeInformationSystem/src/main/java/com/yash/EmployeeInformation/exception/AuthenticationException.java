package com.yash.EmployeeInformation.exception;

public class AuthenticationException {

}
