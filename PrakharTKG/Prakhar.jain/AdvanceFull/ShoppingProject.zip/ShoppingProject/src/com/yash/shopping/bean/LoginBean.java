package com.yash.shopping.bean;


import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import com.yash.shopping.dao.CustomerDao;
import com.yash.shopping.dao.ProductDao;
import com.yash.shopping.pojo.Customer;
import com.yash.shopping.pojo.Product;

@ManagedBean
@SessionScoped
public class LoginBean {
	Customer customer=new Customer();
	private String userName;
	private String password;
	private List<Product> productList;
	
	public List<Product> getList() {
		return productList;
	}
	public void setList(List<Product> productList) {
		this.productList = productList;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String validateLogin(){
		customer=CustomerDao.doLogin(userName,password);
		if(customer!=null){
		return "Login";
		}
		return "Error";
	}
	
	public String selectProduceMen(){
		productList=ProductDao.selectList("men");
		return null;
	}
	
	public String selectProduceWomen(){
		productList=ProductDao.selectList("women");
		return null;
	}
	
	public String selectProduceKids(){
		productList=ProductDao.selectList("kids");
		return null;
	}
	
	public String logout(){
		customer=null;
		return "Logout";
	}
}
