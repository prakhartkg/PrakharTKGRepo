package com.yash.training.tms.exception;

public class AuthenticaticationException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public AuthenticaticationException(String message){
		super(message);
	}
}
