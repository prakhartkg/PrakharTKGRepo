package com.yash.training.tms.exception;

public class PasswordNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
