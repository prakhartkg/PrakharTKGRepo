package com.yash.training.tms.exception;

public class UserNotSaveException extends RuntimeException {
	private static final long serialVersionUID = 1L;
	

}
