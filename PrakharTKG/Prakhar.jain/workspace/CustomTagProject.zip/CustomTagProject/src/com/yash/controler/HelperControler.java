package com.yash.controler;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yash.domain.Customer;



public class HelperControler {
	public static void doProcess(HttpServletRequest request,HttpServletResponse response,Customer customer) throws ServletException, IOException{
		/*String url="/"+(String) request.getAttribute("action");
		System.out.println(url);
		request.getRequestDispatcher(url).forward(request, response);*/
		System.out.println(customer.getName()+" "+customer.getCity()+" "+customer.getAge());
		System.out.println(request);
		System.out.println(response);
	}
}
