package com.customer.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.customer.Connection.CustomerConnection;
import com.customer.Domain.Account;
import com.customer.Domain.Customer;

public class SignInDAO {
	public static Customer checkSignIn(int customerId,String customerPassword){
		Connection connection=CustomerConnection.getConnection();
		Customer customer=new Customer();
		Account account=customer.getAccount();
		//String sql="SELECT * FROM CustomerDetails WHERE customerId=? AND customerPassword=?";
		String sql="SELECT * FROM CustomerDetails cd INNER JOIN accountDetails ad ON cd.customerid=ad.customerid WHERE cd.customerId=? AND cd.customerPassword=?";
		try {
			PreparedStatement preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setInt(1, customerId);
			preparedStatement.setString(2,customerPassword);
			ResultSet resultSet=preparedStatement.executeQuery();
			
			while(resultSet.next()){
				customer.setCustomerId(resultSet.getInt(1));
				customer.setCustomerName(resultSet.getString(2));
				customer.setCustomerCity(resultSet.getString(3));
				customer.setCustomerAddress(resultSet.getString(4));
				account.setAccountNo(resultSet.getInt(6));
				account.setAmount(resultSet.getDouble(7));
				customer.setAccount(account);
				
			}
		}
		catch (SQLException e) {
			System.out.println("Id Not generated");
			e.printStackTrace();
		}

		return customer;
	}
}
