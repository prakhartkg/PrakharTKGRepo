package com.customer.presentation;


import java.util.List;
import java.util.Scanner;

import com.customer.Account.DAO.AccountDAO;
import com.customer.DAO.SignInDAO;
import com.customer.Domain.Customer;
import com.customer.Exceptions.InsufficientBalanceException;

public class SignIn {
	static Customer customer;
	public static void menu(Customer customer){
		int no;
		Scanner scanner=new Scanner(System.in);
		System.out.println("***********************************");
		System.out.println("press 1. to Deposit");
		System.out.println("press 2. to withdraw");
		System.out.println("press 3. to Check Balance");
		System.out.println("press 4. to Transfer");
		System.out.println("press 5. to exit");
		no=scanner.nextInt();
		switch(no){
		case 1:
			System.out.println("Enter Ammount :");
			double ammount=scanner.nextDouble();
			AccountDAO.deposit(customer,ammount);
			break;
		case 2:
			System.out.println("Enter ammount");
			ammount=scanner.nextDouble();
			try {
				AccountDAO.withdraw(customer,ammount);
			} catch (InsufficientBalanceException e) {
				System.out.println("Error : "+e.getMessage());
			}
			break;
		case 3:
			System.out.println("Available Balance : "+AccountDAO.checkBalance(customer.getCustomerId()));
			
			break;
		case 4:
			System.out.println("List of Benificiary.......");
			List<Customer> benificiaries=AccountDAO.showAllBeneficiary();
			for(Customer customerDetail:benificiaries){
				System.out.println(customerDetail);
			}
			System.out.println("**************************");
			System.out.println("Press 1. to add Benificiary");
			System.out.println("Press 2. to remove Benificiary");
			System.out.println("press 3. to Transfer Ammount");
			no=scanner.nextInt();
			switch(no){
			case 1:
				System.out.println("Enter Account no");
				int accountNo=scanner.nextInt();
				System.out.println("Enter Name of Benificary");
				String name=scanner.next();
				AccountDAO.addBenificiary(customer,accountNo,name);
				break;
			case 2:
				break;
			case 3:
				System.out.println("Enter Account No of beneficiary");
				accountNo=scanner.nextInt();
				System.out.println("Enter ammount");
				ammount=scanner.nextDouble();
				//AccountDAO.transferFund(customer.getAccount().getAccountNo(),accountNo,ammount);
				AccountDAO.transferByObject(customer,benificiaries,accountNo,ammount);
				break;
			}
			break;
		case 5:
			System.exit(0);
		}
	}
	public static void signIn(){
		Scanner scanner=new Scanner(System.in);
		
		System.out.println("******************Welcome*****************");
		System.out.print("Customer Id : ");
		int id=scanner.nextInt();
		System.out.print("Password : ");
		String password=scanner.next();
		customer=SignInDAO.checkSignIn(id, password);
		if(customer!=null){
		System.out.println("Welcome..."+customer.getCustomerName());
			do{
			menu(customer);
			}while(true);
		}
	}
}
