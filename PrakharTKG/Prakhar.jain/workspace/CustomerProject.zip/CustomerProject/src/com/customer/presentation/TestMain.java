package com.customer.presentation;

public class TestMain {

	public static void main(String[] args) {
		//SignUp.signUp();
		SignIn.signIn();
	}

}
