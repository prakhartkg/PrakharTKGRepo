abstract class SUV extends Car{
	void a4WheelDrive(){
		
		
	}
	
	
}