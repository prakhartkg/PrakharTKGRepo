class Safari extends SUV{
	// ignition method must be redefined here 
	void ignition(){
		
		System.out.println("Ignition Safari");
	}
	
}