public class Assignment2{
	public static void main(String...args){
	Employee emp=new Employee();
	
	
	System.out.println(emp.incriment());
	System.out.println(Employee.incriment());
	emp.print("RAM","Shyam");
		emp.print("RAM","Shyam","Lakhan");
		
	}
	
}